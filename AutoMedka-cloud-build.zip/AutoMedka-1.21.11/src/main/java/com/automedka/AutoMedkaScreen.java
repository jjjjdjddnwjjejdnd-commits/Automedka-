package com.automedka;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class AutoMedkaScreen extends Screen {
    private boolean enabled = false;
    private boolean goldenCarrot = true;
    private boolean valuableReturn = true;
    private int inventoryPercent = 50;
    private int pvpWait = 30;
    private int supplyRadius = 6;
    private int storageRadius = 8;
    private int actionDelay = 350;

    public AutoMedkaScreen() {
        super(Text.literal("AutoMedka"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 85;
        int w = 220;

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(enabled ? "Status: ON" : "Status: OFF"),
            button -> {
                enabled = !enabled;
                button.setMessage(Text.literal(enabled ? "Status: ON" : "Status: OFF"));
            }
        ).dimensions(cx - w / 2, y, w, 20).build());

        y += 27;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Inventory %: " + inventoryPercent),
            button -> {
                inventoryPercent = inventoryPercent >= 95 ? 20 : inventoryPercent + 5;
                button.setMessage(Text.literal("Inventory %: " + inventoryPercent));
            }).dimensions(cx - w / 2, y, w, 20).build());

        y += 24;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("PvP Wait: " + pvpWait + "s"),
            button -> {
                pvpWait = pvpWait >= 60 ? 5 : pvpWait + 5;
                button.setMessage(Text.literal("PvP Wait: " + pvpWait + "s"));
            }).dimensions(cx - w / 2, y, w, 20).build());

        y += 24;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Supply Radius: " + supplyRadius),
            button -> {
                supplyRadius = supplyRadius >= 16 ? 2 : supplyRadius + 1;
                button.setMessage(Text.literal("Supply Radius: " + supplyRadius));
            }).dimensions(cx - w / 2, y, w, 20).build());

        y += 24;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Storage Radius: " + storageRadius),
            button -> {
                storageRadius = storageRadius >= 20 ? 2 : storageRadius + 1;
                button.setMessage(Text.literal("Storage Radius: " + storageRadius));
            }).dimensions(cx - w / 2, y, w, 20).build());

        y += 24;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Action Delay: " + actionDelay + "ms"),
            button -> {
                actionDelay = actionDelay >= 1000 ? 100 : actionDelay + 50;
                button.setMessage(Text.literal("Action Delay: " + actionDelay + "ms"));
            }).dimensions(cx - w / 2, y, w, 20).build());

        y += 24;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Golden Carrot: " + (goldenCarrot ? "ON" : "OFF")),
            button -> {
                goldenCarrot = !goldenCarrot;
                button.setMessage(Text.literal("Golden Carrot: " + (goldenCarrot ? "ON" : "OFF")));
            }).dimensions(cx - w / 2, y, w, 20).build());

        y += 24;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Valuable Return: " + (valuableReturn ? "ON" : "OFF")),
            button -> {
                valuableReturn = !valuableReturn;
                button.setMessage(Text.literal("Valuable Return: " + (valuableReturn ? "ON" : "OFF")));
            }).dimensions(cx - w / 2, y, w, 20).build());

        y += 27;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"),
            button -> this.close()).dimensions(cx - w / 2, y, w, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, "AutoMedka", this.width / 2,
            this.height / 2 - 108, 0x55FFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
